package com.melkov.cinema.screens.mainscreen.filminfofragment

import com.melkov.cinema.screens.mainscreen.filmlistfragment.FilmListView
import moxy.InjectViewState
import moxy.MvpPresenter

@InjectViewState
class FilmInfoPresenter : MvpPresenter<FilmInfoView>() {

}