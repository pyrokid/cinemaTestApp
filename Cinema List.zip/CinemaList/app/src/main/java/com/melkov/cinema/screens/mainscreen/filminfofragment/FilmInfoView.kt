package com.melkov.cinema.screens.mainscreen.filminfofragment

import moxy.MvpView

interface FilmInfoView: MvpView {
}