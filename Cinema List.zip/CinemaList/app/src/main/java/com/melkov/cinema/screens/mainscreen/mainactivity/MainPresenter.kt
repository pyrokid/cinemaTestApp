package com.melkov.cinema.screens.mainscreen.mainactivity

import com.melkov.cinema.data.t.repository.FilmRepository
import moxy.InjectViewState
import moxy.MvpPresenter

@InjectViewState
class MainPresenter() : MvpPresenter<MainView>() {

    lateinit var filmRepository: FilmRepository

    constructor(filmRepository: FilmRepository) : this() {
        this.filmRepository = filmRepository
    }
}