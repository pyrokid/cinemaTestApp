package com.melkov.cinema.utils

import android.media.Image
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.melkov.cinema.R
import com.melkov.cinema.data.t.model.Films
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.item_film_preview.view.*

class FilmAdapter(films: List<Films>, listener: OnItemClickListener) : RecyclerView.Adapter<FilmAdapter.ViewHolder>() {

    private var listener: OnItemClickListener? = listener

    private lateinit var filmName: TextView
    private lateinit var filmImage: ImageView

    private var films = films



    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        fun bind(film: Films) {
            itemView.film_name.text = film.localized_name
            Picasso.get().load(film.image_url).centerCrop().resize(300, 300).into(itemView.film_image)
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_film_preview, parent, false)

        filmName = view.findViewById(R.id.film_name)
        filmImage = view.findViewById(R.id.film_image)

        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        films.get(position).let { film ->
            holder.bind(film)
        }

        holder.itemView.setOnClickListener { v ->
            listener?.onItemClickListener(v, holder.layoutPosition)
        }
    }

    override fun getItemCount(): Int {
        return films.size
    }

    fun setOnItemClickListener(listener: OnItemClickListener) {
        this.listener = listener
    }

    interface OnItemClickListener {
        fun onItemClickListener(v: View, pos: Int)
    }

}