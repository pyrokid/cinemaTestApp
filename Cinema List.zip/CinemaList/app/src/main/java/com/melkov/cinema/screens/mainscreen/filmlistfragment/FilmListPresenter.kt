package com.melkov.cinema.screens.mainscreen.filmlistfragment

import android.util.Log
import com.melkov.cinema.data.t.model.Films
import com.melkov.cinema.data.t.model.Response
import com.melkov.cinema.data.t.repository.FilmRepository
import moxy.InjectViewState
import moxy.MvpPresenter
import retrofit2.Call
import retrofit2.Callback

@InjectViewState
class FilmListPresenter() : MvpPresenter<FilmListView>() {

    lateinit var filmRepository: FilmRepository
    var genres: MutableSet<String> = mutableSetOf()
    var films: List<Films>? = mutableListOf()

    constructor(filmRepository: FilmRepository) : this() {
        this.filmRepository = filmRepository
    }

    fun loadFilms() {
        filmRepository.getFilmList().enqueue(object : Callback<Response> {
            override fun onFailure(call: Call<Response>, t: Throwable) {
                viewState.showError()
            }

            override fun onResponse(call: Call<Response>, response: retrofit2.Response<Response>) {
                films = response.body()?.films
//                films?.map{
//                    films!!.sortedBy {
//                        it.localized_name
//                    }
//                }
                for (b in films!!) {
                    genres.addAll(b.genres)
                }

                for (b in genres)
                    Log.e("GENRES", b)

                viewState.setupUI(films!!)
                viewState.setupGenres(genres)
            }
        })
    }

    fun loadFilmsByGenre(genre: String) {
        var filmsByGenre = mutableListOf<Films>()
        for (i in films!!) {
            if (i.genres.contains(genre))
                filmsByGenre.add(i)
        }
        viewState.setupUI(filmsByGenre)
    }

}