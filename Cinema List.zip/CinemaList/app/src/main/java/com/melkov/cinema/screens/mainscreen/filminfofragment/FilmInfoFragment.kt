package com.melkov.cinema.screens.mainscreen.filminfofragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.melkov.cinema.R
import com.melkov.cinema.screens.mainscreen.filmlistfragment.FilmListFragment
import com.melkov.cinema.screens.mainscreen.mainactivity.MainActivity
import com.squareup.picasso.Picasso
import moxy.MvpAppCompatFragment
import org.w3c.dom.Text

class FilmInfoFragment : MvpAppCompatFragment(), FilmInfoView {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val args = this.arguments
        val v = inflater.inflate(R.layout.fragment_film_info, container, false)

        val filmTitle = v.findViewById<TextView>(R.id.film_title)
        val filmYear = v.findViewById<TextView>(R.id.film_year)
        val filmRating = v.findViewById<TextView>(R.id.film_rating)
        val filmDescription = v.findViewById<TextView>(R.id.fil_description)
        val filmImage = v.findViewById<ImageView>(R.id.film_image)


        (activity as MainActivity).toolbarBackpressButton.visibility = View.VISIBLE
        (activity as MainActivity).toolbarBackpressButton.setOnClickListener {
            closeFragment()
        }

        args?.let {
            (activity as MainActivity).toolbarHeader.text = it.getString("LOCALIZED_NAME")
            filmTitle.text = it.getString("ORIG_NAME")
            filmYear.text = "Год: " + it.getInt("YEAR").toString()
            filmRating.text = "Рейтинг: " + it.getDouble("RATING").toString()
            filmDescription.text = it.getString("DESCRIPTION")
            Picasso.get().load(it.getString("IMAGE")).centerCrop().resize(500,500).into(filmImage)
        }

        return v
    }

    private fun closeFragment() {
        activity?.supportFragmentManager?.beginTransaction()
            ?.replace(R.id.fragment_storage, FilmListFragment())?.addToBackStack(null)?.commit()
    }

}